<?php 
include('header.php');
?>
<div class="container-fluid">
<div id="main">
    <h3>read json data</h3>
<div id="header">

</div>
<div id="load">
</div>
</div>
</div>
<script type="text/javascript" src="jquery.js"></script>
<script type="text/javascript">
    $(document).ready(function(){
     $.ajax({
      url:'https://jsonplaceholder.typicode.com/posts',
      type:'get',
      success:function(data){
        // console.log(data);
        // $('#load').append("id"+data.id+"<br>"+ data.title +"<br>" +data.body);
      $.each(data ,function(key,value){
        // console.log(value.id +" <br>"+ value.title +"<br> " +value.body);
        $('#load').append(value.id+"<br>"+ value.title +"<br>")
      })
      }
     });
    });
    </script>
<?php
include('footer.php');
?>