<?php 
include('backend/database.php');
$name=$_POST['name'];
// echo $name;

$email=$_POST['email'];
// echo $email;
$phone=$_POST['gender'];
echo $phone;
die;
$sql="INSERT INTO `crud`(`name`, `email`, `phone`) VALUES ('{$name}','{$email}','{$phone}')";
// $result=mysqli_query($conn,$sql) or die('query failed');
if(mysqli_query($conn,$sql)){
    echo "insert successfull";
}else{
    echo "inserti0on failed";
}