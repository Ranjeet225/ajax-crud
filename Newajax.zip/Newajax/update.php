<?php 
include('backend/database.php');
$id=$_POST['id'];
$sql="Select * from crud  where id= {$id}";
$result=mysqli_query($conn,$sql) or die('sql query failed');
$output="";
if(mysqli_num_rows($result)>0){
    while($row=mysqli_fetch_assoc($result)){
        $output.="<label>name</label>  
        <input type='hidden' id='fid' value='{$row['id']}' class='form-control'>
        <input type='text' name='name' id='fname' value='{$row['name']}' class='form-control'><br>
        <label>email</label> 
        <input type='email' name='email' id='femail'  value='{$row['email']}' class='form-control'><br>
        <label>phone</label> 
        <input type='number' name='number' id='fphone' value='{$row['phone']}' class='form-control'><br>
        <button type='button' class='btn btn-primary update'>Update</button>
        ";
    }
   echo $output;
}else{
    echo "record not found";
}


