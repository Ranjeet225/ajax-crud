<?php
include('../header.php');
?>
<style>
    .model {
        background: rgba(0, 0, 0, 0.7);
        position: fixed;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        z-index: 100;
        display: none;
    }

    .model-box {
        background: #fff;
        margin: auto;
        width: 40%;
        position: relative;
        top: 20%;
        left: calc(50%-15%);
        padding: 15px;
        border-radius: 4px;
    }

    #close {
        background: red;
        color: white;
        width: 30px;
        height: 30px;
        text-align: center;
        line-height: 30px;
        border-radius: 50%;
        position: absolute;
        padding: 0px;
        top: -35px;
        right: -15px;
        cursor: pointer;
    }
</style>
<div class="container-fluid" style="width:70%;margin-top:5%">
    <div class="model">
        <div class="model-box">
        <div>
            <h4 style="text-align:center">Add record</h4>
            
            <form id="reset">
                <div class="form-group">
                    <label for="">Name</label>
                    <input type="text" name="name" id="name" class="form-control" placeholder="" aria-describedby="helpId">
                </div>
                <div class="form-group">
                    <label for="">Email</label>
                    <input type="text" name="email" id="email" class="form-control" placeholder="" aria-describedby="helpId">
                </div>
                <div class="form-group">
                    <label for="">Phone number</label>
                    <input type="text" name="phone" id="phone" class="form-control" placeholder="" aria-describedby="helpId">
                </div>
            </form>
            <button type='button' class='btn btn-primary float-right insert'>Insert</button>
        </div>
            <button type='button' class='btn btn-info' id='close'>X</button>
        </div>
    </div>
    <!-- <button type="button" class="btn btn-primary button">load data</button> -->
    <button type="button" class="btn btn-light add_data" style="float:right; ">Add data</button>
    <input type="search" id="search" placeholder="enter character ">: Search
    <table class="table" cellpadding="0" cellspacing='0' width="100%">
        <thead>
            <tr>
                <th>id</th>
                <th>name</th>
                <th>email</th>
                <th>phone</th>
                <th>edit</th>
                <th>delete</th>
            </tr>
        </thead>
        <tbody id="data">
            <tr>
                <td scope="row"></td>
                <td></td>
                <td></td>
                <td></td>
            </tr>
        </tbody>
    </table>
</div>
<script type="text/javascript" src="../jquery.js"></script>
<script type="text/javascript">
    $(document).ready(function() {
                function load() {
                    $.ajax({
                        url: 'select.php',
                        type: 'post',
                        success: function(data) {
                            $('#data').html(data);
                        }
                    });
                }
                load();
                $(document).on('click', '.add_data', function() {
                    $('.model').show();
                });
                $(document).on('click', '#close', function() {
                    $('.model').hide();
                });
                $(document).on('click', '.insert', function() {
                    var fname = $('#name').val();
                    var femail = $('#email').val();
                    var fphone = $('#phone').val();
                    $.ajax({
                        url: 'insert.php',
                        type: 'post',
                        data: {
                            name: fname,
                            email: femail,
                            phone: fphone
                        },
                        success: function(data) {
                            alert(data);
                            load();
                            // $('#reset').trigger('reset');\
                            $('#reset').trigger('reset');
                            $('.model').hide();
                        }
                    });
                });
                $(document).on('click', '.delete', function() {
                    var fid = $(this).data('id');
                    $.ajax({
                        url: 'delete.php',
                        type: 'post',
                        data: {
                            id: fid
                        },
                        success: function(data) {
                            load();
                            alert(data);
                        }
                    });
                });
            $(document).on('keyup', '#search', function() {
             var search=$(this).val();
             $.ajax({
                url:'search.php',
                type:'post',
                data:{id:search},
                success:function(data){
                 $('#data').html(data);
                }
             });
            });
            $(document).on('click', '.edit', function() {
                var fid=$(this).data('eid');
                $.ajax({
                    url:'edit.php',
                    type:'post',
                    data:{id:fid},
                    success:function(data){
                        $('.model').show();
                        $('.model-box div').html(data);
                    }
                });
            });
            $(document).on('click', '.update', function() {
                var fid=$('#eid').val();
                var fname=$('#name').val();
                var femail=$('#email').val();
                var fphone=$('#phone').val();
                $.ajax({
                    url:'update.php',
                    type:'post',
                    data:{id:fid,name:fname,email:femail,phone:fphone},
                    success:function(data){
                        alert(data);
                        $('.model').hide();
                        load();
                    }
                });
        });
    });
</script>
<?php
include('../footer.php');
// include('../backend/database.php');
// $sql="SELECT *FROM crud";
// $result=mysqli_query($conn,$sql) or die('sql query failed');
// $out="";
// if(mysqli_num_rows($result)>0){
//      $i=1;
//     while($row=mysqli_fetch_assoc($result)){
//         $out.="<tr>
//         <td>{$i}</td>
//         <td>{$row['name']}</td>
//         <td>{$row['email']}</td>
//         <td>{$row['phone']}</td>
//         <td> <button type='button' class='btn btn-primary edit' data-eid='{$row['id']}'>Edit</button></td>
//         <td> <button type='button' class='btn btn-warning delete' data-id='{$row['id']}'>Delete</button> </td>
//         </tr>";
//         $i++;
//     }

//     echo $out;
// }else{
//     echo "record not found";
// }
?>