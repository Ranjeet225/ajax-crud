<?php 
include('../backend/database.php');
$sql="SELECT *FROM crud";
$result=mysqli_query($conn,$sql) or die('sql query failed');
$out="";
if(mysqli_num_rows($result)>0){
     $i=1;
    while($row=mysqli_fetch_assoc($result)){
        $out.="<tr>
        <td>{$i}</td>
        <td>{$row['name']}</td>
        <td>{$row['email']}</td>
        <td>{$row['phone']}</td>
        <td> <button type='button' class='btn btn-primary edit' data-eid='{$row['id']}'>Edit</button></td>
        <td> <button type='button' class='btn btn-warning delete' data-id='{$row['id']}'>Delete</button> </td>
        </tr>";
        $i++;
    }
    $out.="<div id='pegination'>
    <a href='1' class='active'>1</a>
    <a href='3' >2</a>
    <a href='1' >3</a>
    </div>";
echo $out;
}else{
    echo "record not found";
}
?>