<?php 
include('../backend/database.php');
$id=$_POST['id'];
$sql="SELECT * FROM crud where id= {$id}";
$result=mysqli_query($conn,$sql);
$out="";
if(mysqli_num_rows($result)>0){
    while($row=mysqli_fetch_assoc($result)){
        $out.=" 
        <form id='reset'>
        <h4>Edit record</h4>
        <div class='form-group'>
            <label for=>Name</label>
            <input type='hidden' id='eid' value='{$row['id']}' class='form-control' >
            <input type='text' name='name' id='name' value='{$row['name']}' class='form-control' >
        </div>
        <div class='form-group'>
            <label >Email</label>
            <input type='text' name='email' id='email' value='{$row['email']}' class='form-control' >
        </div>
        <div class='form-group'>
            <label>Phone number</label>
            <input type='text' name='phone' id='phone' value='{$row['phone']}' class='form-control' >
        </div>
    </form>
    <button type='button' class='btn btn-primary float-right update'>Update</button>
        ";
    }
    echo $out;
}else{
    echo "record not found";
}