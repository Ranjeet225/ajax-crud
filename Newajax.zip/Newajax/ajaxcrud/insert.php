<?php 
include('../backend/database.php');
$name=$_POST['name'];
$email=$_POST['email'];
$phone=$_POST['phone'];
$sql ="INSERT INTO `crud`(`name`, `email`, `phone`) VALUES ('{$name}','{$email}','{$phone}') ";
if(mysqli_query($conn,$sql)){
    echo "record inserted successfully";
}else{
    echo "error occur";
}