<?php 
include('backend/database.php');
$id=$_POST['id'];
$name=$_POST['name'];
$email=$_POST['email'];
$phone=$_POST['phone'];
$sql="UPDATE crud SET name='{$name}',email='{$email}',phone='{$phone}'  WHERE id={$id}";
if(mysqli_query($conn,$sql)){
    echo "update succesfull successfull";
}else{
    echo "update failed";
}