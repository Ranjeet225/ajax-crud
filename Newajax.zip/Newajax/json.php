<?php
include('header.php');
?>
<div class="container-fluid">

<div id="main">
    <div id="header">


    </div>
</div>
</div>
<script type="text/javascript" src="jquery.js"></script>
<script type="text/javascript">
$(document).ready(function(){
$.ajax({
    // url:'https://jsonplaceholder.typicode.com/posts',
    url:'sjson.php',
    type:'POST',
    datatype:'JSON',
    success:function(data){
    // console.log(data);
     $.each(data,function(key,value){
        $('#header').append(value.name+" "+value.email);
     });
    }
});
});
</script>
<?php 
include('footer.php');
?>