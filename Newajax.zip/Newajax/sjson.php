<?php
$hello="ranjeet kumar maurya ";
$name="hello";
echo $$name,$name;

?>


<?php
// include('backend/database.php');
// $sql="SELECT *FROM crud ";
// $result=mysqli_query($conn,$sql);
// $row=mysqli_fetch_all($result,MYSQLI_ASSOC);
// $row1=json_encode($row);
// echo(json_encode($row));

