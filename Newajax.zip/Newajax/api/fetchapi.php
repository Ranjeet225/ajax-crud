<?php
header("CONTENT_TYPE:application/json");
header("Access-Control-Allow-Origin:*");
include('config.php');

$sql="SELECT *FROM crud";
$result=mysqli_query($conn,$sql);
if(mysqli_num_rows($result)>0){
    $out=mysqli_fetch_all($result,MYSQLI_ASSOC);
    echo (json_encode($out,true));
}else{
    echo (json_encode(['message'=>'record not found','status'=>false]));
}


