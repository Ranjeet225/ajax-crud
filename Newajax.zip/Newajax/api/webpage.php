<?php
include('header.php');
?>
<div class="container-md col-10 shadow-lg p-3 mb-5 bg-grey rounded mx-auto">
    <table class="table">
        <tr class="bg-secondary">
            <td scope="row">CRUD OPERATION IN REST API<input type="search" placeholder="search" class="float-right"></td>
        </tr>
        <tr class="ml-24 bg-success">
            <td>
                <input type="text" placeholder="enter your name" name="name" id="name" class="ml-5">:name
                <input type="email" placeholder="enter your email" name="email" id="email">:email
                <input type="number" placeholder="enter your name" name="number" id="number">:number
                <button type="button" class="btn btn-primary" id="save">save</button>
            </td>
        </tr>
    </table>
    <table width="100%" cellpadding="10px" cellspacing="0px" border="2px">
        <tr>
            <thead>
                <th>id</th>
                <th>name</th>
                <th>email</th>
                <th>phone</th>
                <th>edit</th>
                <th>delete</th>
            </thead>
        </tr>
        <tr>
            <tbody>
                <td>ranjeet</td>
                <td>sanjet</td>
                <td>arnav</td>
                <td>lavanya</td>
                <td><button type="button" class="btn btn-primary">edit</button></td>
                <td><button type="button" class="btn btn-warning">delete</button></td>
            </tbody>
        </tr>

        </tbody>
    </table>

</div>
<script type="text/javascript" src="jquery.js"></script>
<script type="text/javascript">
$(document).ready(function(){
function load(){
$.ajax({
    url:'http://localhost/newajax/api/selectall.php',
    type:'post',
    success:function(data){
        console.log(data);
    }
}); 
}
load();
    });
</script>
<?php
include('footer.php');
?>