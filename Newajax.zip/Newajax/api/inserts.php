<?php
header('content-type:application/json');
header('access-control-allow-origin:*');
header('access-control-allow-method:post');
header('access-control-allow-headers:access-control-allow-headers,access-control-allow-origin
access-control-allow-method,content-type,authrization,X-requested-with');
$data=json_decode(file_get_contents('php://input'),true);
$name=$data['name'];
$email=$data['email'];
$phone=$data['phone'];
include('config.php');
$sql="INSERT INTO crud(name,email,phone) values('{$name}','{$email}','{$phone}')";
if(mysqli_query($conn,$sql)){
    echo json_encode(['message'=>'data inserted sucessfully','status'=>true]);
}else{
    echo json_encode(['message'=>'failed to insert data','status'=>false]);
}