<?php
header("CONTENT_TYPE:application/json");
header("Access-Control-Allow-Origin:*");


$data=json_decode(file_get_contents("php://input"),true);
$student=$data['sid'];
include('config.php');

$sql="SELECT *FROM crud where id={$student}";
$result=mysqli_query($conn,$sql);
if(mysqli_num_rows($result)>0){
    $out=mysqli_fetch_all($result,MYSQLI_ASSOC);
    echo (json_encode($out,true));
}else{
    echo (json_encode(['message'=>'record not found','status'=>false]));
}



?>