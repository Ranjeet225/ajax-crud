<?php
header('content-type:application/json');
header('access-control-allow-method:post');
header('access-control-allow-origin:*');
header('access-control-allow-header:access-control-allow-method:');
$data=json_decode(file_get_contents("php://input"),true);
$student=$data['search'];
include('config.php');

$sql="SELECT *FROM crud where name like '%$student%' or email like '%$student%' ";
$result=mysqli_query($conn,$sql);
if(mysqli_num_rows($result)>0){
    $out=mysqli_fetch_all($result,MYSQLI_ASSOC);
    echo (json_encode($out,true));
}else{
    echo (json_encode(['message'=>'record not found','status'=>false]));
}
