<?php
header('content-type:application/json');
header('access-control-allow-origin:*');
header('access-control-allow-methods:post');
header('access-control-allow-headers:access-control-allow-headers,
content-type,access-control-allow-methods,authrization,X-requested-with');


$data=json_decode(file_get_contents("php://input"),true);
$name=$data['sname'];
$email=$data['semail'];
$phone=$data['sphone'];
include('config.php');
$sql="INSERT INTO crud(name,email,phone) values('{$name}','{$email}',{$phone})";
if(mysqli_query($conn,$sql)){
    echo json_encode(['message'=>'data inserted succesfully','status'=>true]);
}else{
    echo json_encode(['message'=>'failed data inserted successfully','status'=>false]);

}


?>